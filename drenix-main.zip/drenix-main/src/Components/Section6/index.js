import Section6 from "./Section6";

export default Section6