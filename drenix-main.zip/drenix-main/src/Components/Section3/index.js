import Section3 from "./Section3";
export default Section3