import Section7 from "./Section7";

export default Section7