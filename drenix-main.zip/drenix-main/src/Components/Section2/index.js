import Section2 from "./Section2";

export default Section2